from django.apps import AppConfig


class OCLettingsSiteConfig(AppConfig):
    name = 'oc_lettings_site'
